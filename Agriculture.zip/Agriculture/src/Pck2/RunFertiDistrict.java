package Pck2;

import org.testng.annotations.Test;


public class RunFertiDistrict extends ActorFertiDist {
	@Test
	public static void Endosment() throws InterruptedException, Exception {
		ActorFertiDist.Setup();
		//ActorFertiDist.FertiDistrictADO();
		//ActorFertiDist.
		ActorFertiDist.CAO();
		//ActorFertiDist.PaymentLO();
	}

}
