package Pck2;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ActorPestidist {
	static WebDriver driver;

	public static void Setup() throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriverss.exe");
		driver = new ChromeDriver();
	}
	@SuppressWarnings("deprecation")
	public static void PestDistADO() throws InterruptedException {
		
		  driver.get("https://eagriservicesdev.psegs.in/");
		  driver.manage().window().maximize();
		 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[2]/a"))
				.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("P_ADO_Amritsar");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		Thread.sleep(3000);
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/a/p"))
				.click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/ul/li[4]/a/p"))
				.click();
		driver.findElement(By.xpath(".//tr[1]//*[@id=\"dropdownMenuButton\"]")).click();
		driver.findElement(By.xpath(".//tr[1]//td[8]//*[text()='Perform Action']")).click();
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[1]/div/div/select"))
				.click();
		
		//For negative Flow
		driver.findElement(By.xpath("//*[text()= 'Mark file as incomplete and send back to applicant ']")).click();
		
		//For Positive flow
		//driver.findElement(By.xpath("//*[text()= 'Mark file as verified ok and send to LO  ']")).click();
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[2]/div/div/textarea"))
				.sendKeys("okay");
		driver.findElement(By.xpath("//*[text()='Submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()=' Logout']")).click();
	}
	
	public static void ResolveObjection() throws Exception{
		 driver.get("https://eagriservicesdev.psegs.in/");
		  driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		/*
		 * driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
		 * .click();
		 * driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys(
		 * "7555555557");
		 * driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys(
		 * "Punjab@123"); String captchaVal =
		 * JOptionPane.showInputDialog("Please enter the captcha value:"); // Type the
		 * entered captcha to the text box
		 * driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(
		 * captchaVal);
		 * driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		 * driver.findElement( By.xpath(
		 * "/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[6]/a/p"
		 * )) .click(); driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-main/div[1]/app-resolveobjection/section/div[1]/div/div/fieldset/div/div/div/table/tbody/tr/td[6]/div/input"
		 * )) .click();
		 * driver.findElement(By.xpath("//*[text()= 'Submit Request']")).click(); Alert
		 * alert = driver.switchTo().alert(); alert.accept(); Thread.sleep(3000);
		 * driver.findElement(By.xpath("//*[text()=' Logout']")).click();
		 */
		
// Login ADO Again
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[2]/a"))
				.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("P_ADO_Amritsar");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		Thread.sleep(3000);
		String captchaVal1 = JOptionPane.showInputDialog("Please enter the captcha value:");
// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal1);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/a/p"))
				.click();
		driver.findElement(By
				.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/ul/li[4]/a/p"))
				.click();
		driver.findElement(By.xpath(".//tr[1]//*[@id=\"dropdownMenuButton\"]")).click();
		driver.findElement(By.xpath(".//tr[1]//td[8]//*[text()='Perform Action']")).click();
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[1]/div/div/select"))
				.click();

//For negative Flow
		driver.findElement(By.xpath("//*[text()= 'Mark file as incomplete and send to LO ']")).click();

//For Positive flow
		//driver.findElement(By.xpath("//*[text()= 'Mark file as complete and send to LO ']")).click();
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[2]/div/div/textarea"))
				.sendKeys("okay");
		driver.findElement(By.xpath("//*[text()='Submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()=' Logout']")).click();
	}

	@SuppressWarnings("deprecation")
	public static void PestDistLO() throws InterruptedException {

		
		
		  driver.get("https://eagriservicesdev.psegs.in/");
		  driver.manage().window().maximize();
		 
		 

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[2]/a"))
				.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("P_CAO_Amritsar");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[7]/a/p"))
				.click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[7]/ul/li[4]/a/p"))
				.click();
		driver.findElement(By.xpath("//*[@id=\"dropdownMenuButton\"]")).click();
		
		  driver.findElement(By.xpath(
		  "/html/body/div/app-root/app-main/div[1]/app-application-listing/section/div/div/div/fieldset/div[1]/div[4]/div/table/tbody/tr/td[8]/div/div/a[3]"
		  )).click(); driver.findElement(By.xpath("//*[@name='ddlAction']")).click();
	//For Reject File
		  driver.findElement(By.xpath("//*[text()='Reject file ']")).click();
		  driver.findElement(By.xpath(
					"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[2]/div/div/textarea"))
					.sendKeys("File rejected Due to Incompletion");
		  driver.findElement(By.xpath("//*[text()='Submit']")).click();
   // for positive flow
	/*
	 * driver.findElement(By.xpath("//*[text()='Generate output ']")).click();
	 * driver.findElement(By.xpath("//*[@type='button']")).click();
	 * 
	 * 
	 * Thread.sleep(5000);
	 * 
	 * driver.findElement(By.xpath(
	 * "/html/body/div/app-root/app-main/div[1]/app-application-listing/section/div/div/div/fieldset/div[1]/div[4]/div/table/tbody/tr/td[8]/div/button"
	 * )) .click();
	 * driver.findElement(By.xpath("//*[text()='Perform Action']")).click();
	 * Thread.sleep(5000); driver.findElement(By.xpath(
	 * "/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[1]/div/div/select"
	 * )) .click();
	 * 
	 * driver.findElement(By.xpath("//*[text()='Issue license to applicant ']")).
	 * click();
	 * 
	 * driver.findElement(By.xpath("//*[@value='Issue Esign License']")).click();
	 * driver.findElement(By.xpath("//*[@id='pin']")).sendKeys("310587");
	 * driver.findElement(By.xpath("//input[@value= 'TOTP']")).click();
	 * 
	 * 
	 * String totpval = JOptionPane.showInputDialog("Please enter the TOTP Value:");
	 * // Type the entered captcha to the text box
	 * driver.findElement(By.xpath("//*[@id='otpval']")).sendKeys(totpval); //
	 * driver.findElement(By.xpath("//*[@id='otpval']")).click();
	 * //Thread.sleep(10000);
	 * driver.findElement(By.xpath("//*[@id=\"checkagree\"]")).click();
	 * driver.findElement(By.xpath("//*[@id=\"esignperform\"]")).click();
	 */
	}
}
