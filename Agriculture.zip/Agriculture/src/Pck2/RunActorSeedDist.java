package Pck2;

import org.testng.annotations.Test;

public class RunActorSeedDist extends ActorSeedDist {
		@Test
		public static void Endosment() throws InterruptedException, Exception {
			ActorSeedDist.Setup();
			//ActorSeedDist.SeedDistADO();
			ActorSeedDist.ResolveObjection();
			ActorSeedDist.SeedHQLO();
		}
}
