package Pck2;

import org.testng.annotations.Test;

public class RunActorSeedHQ extends ActorSeedHQ {
		@Test
		public static void Endosment() throws InterruptedException, Exception {
			ActorSeedHQ.Setup();
			//ActorSeedHQ.SeedHQADO();
			//ActorSeedHQ.ResolveObjection();
			ActorSeedHQ.SeedHQLO();
		}
}
