package Pck2;

import org.testng.annotations.Test;

public class RunActorFertiState extends ActorFerti  {
		@Test
		public static void Endosment() throws InterruptedException, Exception {
			ActorFerti.Setup();
			ActorFerti.FertiStaeADO();
			ActorFerti.CAO();
			ActorFerti.PaymentLO();
		}

}
