package Pck2;

import org.testng.annotations.Test;

public class RunActorPestDist extends ActorPestidist {
	@Test
	public static void Endosment() throws InterruptedException, Exception {
		ActorPestidist.Setup();
		ActorPestidist.PestDistADO();
		ActorPestidist.ResolveObjection();
		ActorPestidist.PestDistLO();
	}

}
