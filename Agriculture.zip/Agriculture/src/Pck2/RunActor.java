package Pck2;

import org.testng.annotations.Test;

public class RunActor extends Actors {
		@Test
		public static void Endosment() throws InterruptedException, Exception {
			Actors.Setup();
			Actors.PestManuActor();
			Actors.PestManuLO();
		}
}
