package pck1;

import org.testng.annotations.Test;

public class RunPMChangeRP extends PMChResponsibleP{
	@Test
	public static void Endosment() throws InterruptedException, Exception {
		PMChResponsibleP.Setup();
		PMChResponsibleP.login();
		PMChResponsibleP.ChangeResponsiblePerson();
		//PestManuEndosment.PestManuActor(); 
		//PestManuEndosment.PestManuLO();
		 
	}
}
