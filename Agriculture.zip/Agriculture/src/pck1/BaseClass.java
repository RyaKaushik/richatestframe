package pck1;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class BaseClass extends PestManuCls{
	
	static WebDriver driver;
	@Test
	public void AgriLicense() throws Exception{
		PestManuCls.Setup();
		PestManuCls.login();
		PestManuCls.ApplyPestManuNew();
		PestManuCls.Form2();
		PestManuCls.Form3();
	}
	
}
