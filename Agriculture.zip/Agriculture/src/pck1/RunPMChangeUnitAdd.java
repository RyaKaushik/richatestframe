package pck1;

import org.testng.annotations.Test;

public class RunPMChangeUnitAdd {
	@Test
	public static void Endosment() throws InterruptedException, Exception {
		PMChangeUnitAdd.Setup();
		PMChangeUnitAdd.login();
		PMChangeUnitAdd.ChangeUnitAdd();
		PMChangeUnitAdd.PestManuActor();
		PMChangeUnitAdd.PestManuLO();
	}
}
