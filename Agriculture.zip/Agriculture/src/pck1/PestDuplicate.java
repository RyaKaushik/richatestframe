package pck1;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class PestDuplicate {
	static WebDriver driver;

	public static void Setup() throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@SuppressWarnings("deprecation")
	public static void login() throws Exception {
		driver.get("https://eagriservicesdev.psegs.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
				.click();
		driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys("7555555557");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		// Thread.sleep(3000);
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		Thread.sleep(4000);
	}

	@SuppressWarnings("deprecation")
	public static void PestManuDuplicate() throws Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/a")).click();
		// Thread.sleep(3000);
		driver.findElement(By
				.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[4]/a/p"))
				.click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[4]/ul/li[6]/a/p"))
				.click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"LicenseNumber\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"LicenseNumber\"]/option[3]")).click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"Reason_For_Duplicate\"]")).sendKeys("Misplaced");
		WebElement U1 = driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[1]/fieldset/div/div[2]/div/div[1]/div/div/input"));
		U1.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		WebElement U2 = driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[1]/fieldset/div/div[2]/div/div[2]/div/div/input"));
		U2.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		driver.findElement(By.xpath("/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[2]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("/html/body/div/app-root/app-main/app-header/nav/ul[2]/li[2]/a")).click();
	}

	@SuppressWarnings("deprecation")
	public static void PestManuActor() throws InterruptedException {
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[2]/a"))
				.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("P_DD_LCPP");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		Thread.sleep(3000);
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		// Thread.sleep(3000);
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/a/p"))
				.click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/a/p"))
				.click();
		// Thread.sleep(3000);
		driver.findElement(By
				.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/ul/li[3]/a/p"))
				.click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath(".//tr[10]//*[@id=\"dropdownMenuButton\"]")).click();
		// Thread.sleep(2000);
		driver.findElement(By.xpath(".//tr[10]//td[8]//*[text()='Perform Action']")).click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[1]/div/div/select"))
				.click();
		driver.findElement(By.xpath("//*[text()= 'Send file to applicant for payment ']")).click();
		// driver.findElement(By.xpath("/html/body/div/app-root/app-main/div[1]/app-manufacture-pendancydetail/section/form/div/div/div/div[1]/div/div/fieldset/div[2]/div/div/textarea")).sendKeys("okay");
		driver.findElement(By.xpath("//button[text()= 'Initiate Payment']")).click();
		driver.findElement(By.xpath("//button[text()= ' Send to Applicant']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()=' Logout']")).click();
	}

	public static void PayCitizen() throws InterruptedException {
		
		  driver.findElement(By.xpath(
		  "/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
		  .click();
		  driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys(
		  "7555555557");
		  driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys(
		  "Punjab@123"); //Thread.sleep(3000); String captchaVal =
		  JOptionPane.showInputDialog("Please enter the captcha value:"); 
		  // Type the entered captcha to the text box
		  driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys("captchaVal");
		  driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		 
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[5]/a")).click();
		driver.findElement(By.xpath("//*[@value= 'Pay Fee']")).click();
		//Alert to switch IFMPaymentsite site
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/button")).click();
		Thread.sleep(6000);
		Alert alert=driver.switchTo().alert();
		alert.accept();
		//Thread.sleep(5000);
		//driver.findElement(By.xpath("//button[text()= 'Continue']")).click();
	}

	@SuppressWarnings("deprecation")
	public static void PestManuLO() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[2]/a"))
				.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("P_DA");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[4]/a/p"))
				.click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[text()=' Logout']")).click();
	}
}
