package pck1;

import org.testng.annotations.Test;

public class RunPMChangeOfcAdd extends PMChangeOfficeAdd {
	@Test
	public static void Endosment() throws InterruptedException, Exception {
		PMChangeOfficeAdd.Setup();
		PMChangeOfficeAdd.login();
		PMChangeOfficeAdd.ChangeOfficeAdd();
		PMChangeOfficeAdd.PestManuActor();
		PMChangeOfficeAdd.PestManuLO();
	}
}
