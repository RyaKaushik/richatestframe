package pck1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class RunPManDupl extends PestDuplicate{
	static WebDriver driver;
	@Test
	public void AgriLicense() throws Exception{
		PestDuplicate.Setup();
		PestDuplicate.login();
		PestDuplicate.PestManuDuplicate();
		PestDuplicate.PestManuActor();
		PestDuplicate.PayCitizen();
	    PestDuplicate.PestManuLO();
	}
	
}
