package pck1;

import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class datePicker {
	static WebDriver driver;

	@Test

	public void Gsearch() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\selnium\\Driver\\chromedriver_win32 (1)\\chromedriverss.exe");
		driver = new ChromeDriver();
		driver.get("\r\n"
				+ "https://eagriservicesdev.psegs.in/Login/Citizen");
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
				//.click();
		driver.findElement(By.xpath("/html/body/div/app-root/app-login-common/div/div/form/div[3]/input"))
				.sendKeys("7555555557");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();

		Thread.sleep(3000);
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/a")).click();
		Thread.sleep(3000);
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[4]/a"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[4]/ul/li[2]/a/p"))
				.click();
//driver.findElement(By.id("LicenseNumber")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"//*[@id=\"cdk-step-content-0-0\"]/div/div/form/div[1]/div/fieldset[3]/div[1]/div/fieldset[1]/div/div[8]/div/div/div/mat-datepicker-toggle/button"))
				.click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div/mat-month-view/table/tbody/tr[4]/td[3]/div[1]"))
				.click();

	}
}
