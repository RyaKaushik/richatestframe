package pck1;


import org.testng.annotations.Test;

public class RunPestManuEndos extends PestManuEndosment {
@Test
public static void Endosment() throws InterruptedException, Exception {
	PestManuEndosment.Setup();
	PestManuEndosment.login();
	PestManuEndosment.Endosment();
	PestManuEndosment.PestManuActor();
	PestManuEndosment.PestManuLO();
}
}
