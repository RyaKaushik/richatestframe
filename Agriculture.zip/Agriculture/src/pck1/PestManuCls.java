package pck1;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PestManuCls {
	static WebDriver driver;
	public static void Setup() throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	public static void login() throws Exception {
		driver.get("https://agritst.psegs.in/");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
				.click();
		driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys("7897897897");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("123456");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		Thread.sleep(3000);
	}

	public static void ApplyPestManuNew() throws Exception {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//p[text()='Apply for New License ']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//p[text()='Pesticide Manufacturer ']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@class= 'btn custom-btn']| //button[@class= 'btn']")).click();
		driver.findElement(By.xpath("//input[@name= 'ApplicantName']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name= 'ApplicantName']")).sendKeys("Testing");
		driver.findElement(By.xpath("//input[@id= 'FatherName']")).clear();
		driver.findElement(By.xpath("//input[@id= 'FatherName']")).sendKeys("Test Father");
		driver.findElement(By.xpath("//input[@id= 'Design']")).clear();
		driver.findElement(By.xpath("//input[@id= 'Design']")).sendKeys("CEO");
		driver.findElement(By.xpath("//input[@id= 'NameofFirm']")).clear();
		driver.findElement(By.xpath("//input[@id= 'NameofFirm']")).sendKeys("Test Pest Frim Pvt. Lt.");
		Thread.sleep(2000);
		WebElement Upload = driver.findElement(By.xpath("//input[@class='form-control col-md-6 mb-1 mr-2']"));
		Upload.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		driver.findElement(By.xpath("//button[@class= 'btn']")).click();
		Thread.sleep(3000);
	}
	public static void Form2() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[1]/div/div/div/div[1]/textarea")).clear();
		driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[1]/div/div/div/div[1]/textarea"))
				.sendKeys("Testing,sector 23");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"StateID\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"StateID\"]/option[30]")).click();
		driver.findElement(By.xpath("//*[@id='District']/option[2]"))
				.click();
		driver.findElement(By.xpath("//input[@id='pincode']")).clear();
		driver.findElement(By.xpath("//input[@id='pincode']")).sendKeys("565656");
		driver.findElement(By.xpath("//input[@id='Email']")).clear();
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("test@g.in");
		driver.findElement(By.xpath("//input[@id='contactNo']")).clear();
		driver.findElement(By.xpath("//input[@id='contactNo']")).sendKeys("7555555557");
		driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[2]/div/div[1]/textarea")).clear();
		driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[2]/div/div[1]/textarea"))
				.sendKeys("34B, sector 67");
		driver.findElement(By.xpath("//*[@id='WorkDistId']//option[2]")).click();
		driver.findElement(By.xpath("//input[@id='Workpincode']")).clear();
		driver.findElement(By.xpath("//input[@id='Workpincode']")).sendKeys("676767");
		driver.findElement(By.xpath("//input[@id='WorkEmail']")).clear();
		driver.findElement(By.xpath("//input[@id='WorkEmail']")).sendKeys("test@g.in");
		driver.findElement(By.xpath("//input[@id='WorkcontactNo']")).clear();
		driver.findElement(By.xpath("//input[@id='WorkcontactNo']")).sendKeys("7555555557");
		WebElement U1 = driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[2]/div/div[6]/div/input"));
		U1.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		WebElement U2 = driver.findElement(By.xpath("//*[@id=\"cdk-step-content-0-1\"]/form/div/div/div/div[1]/div/div/fieldset[2]/div/div[7]/div/input"));
		U2.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type= 'submit' ]/ancestor::div[contains(@class,'col-md-12 text-center custom-btns')]")).click();
	}
	public static void Form3() throws InterruptedException {
		Thread.sleep(3000);
		/*
		 * WebElement U3 = driver.findElement(By.xpath(
		 * "//*[@id=\"cdk-step-content-1-2\"]/div/div/div/div[1]/div/fieldset/div/div[2]/div/input"
		 * )); U3.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		 * WebElement U4 = driver.findElement(By.xpath(
		 * "//*[@id=\"cdk-step-content-1-2\"]/div/div/div/div[1]/div/fieldset/div/div[5]/div/input"
		 * )); U4.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		 */
		driver.findElement(By.xpath("//*[@id=\"cdk-step-content-2-2\"]/div/div/div/div[2]/div/button[2]")).click();
	}
	
	
}
