package pck1;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FertiStateDuplicate {
	static WebDriver driver;

	public static void Setup() throws InterruptedException, AWTException {
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@SuppressWarnings("deprecation")
	public static void login() throws Exception {
		driver.get("https://eagriservicesdev.psegs.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
				.click();
		driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys("7555555557");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("Punjab@123");
		// Thread.sleep(3000);
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		Thread.sleep(4000);
	}

	@SuppressWarnings("deprecation")
	public static void PestManuDuplicate() throws Exception {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(
				By.xpath("/html/body/div/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/a")).click();
		// Thread.sleep(3000);
		driver.findElement(By
				.xpath("/html/body/div[1]/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[1]/a"))
				.click();
		// Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html/body/div[1]/app-root/app-main/app-menu/aside/div/div[4]/div/div/nav/ul/li[2]/ul/li[1]/ul/li[7]/a"))
				.click();
		// Thread.sleep(3000);
		/*
		 * driver.findElement(By.xpath("//*[@id=\"LicenseNumber\"]")).click();
		 * driver.findElement(By.xpath("//*[@id=\"LicenseNumber\"]/option[2]")).click();
		 * // Thread.sleep(3000);
		 * driver.findElement(By.xpath("//*[@id=\"Reason_For_Duplicate\"]")).sendKeys(
		 * "Misplaced"); WebElement U1 = driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[1]/fieldset/div/div[2]/div/div[1]/div/div/input"
		 * )); U1.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		 * WebElement U2 = driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[1]/fieldset/div/div[2]/div/div[2]/div/div/input"
		 * )); U2.sendKeys("C:\\Users\\admin\\Downloads\\my work\\ferti.pdf");
		 * driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-main/div[1]/app-duplicate-license/div/section/div/div/fieldset/div[2]/form/div/div[2]/button"
		 * )).click(); Thread.sleep(4000); driver.findElement(By.xpath(
		 * "/html/body/div/app-root/app-main/app-header/nav/ul[2]/li[2]/a")).click();
		 */
	}
}
