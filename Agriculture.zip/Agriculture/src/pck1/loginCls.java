package pck1;

import javax.swing.JOptionPane;

import org.bouncycastle.oer.its.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class loginCls {
	WebDriver driver;
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://agritst.psegs.in/");
		driver.manage().window().maximize();
	}
	public void signin() throws Exception {
		
		
		driver.findElement(By.xpath("/html/body/div/app-root/app-index/app-headerindex/div/nav/div/ul/li[3]/a"))
				.click();
		driver.findElement(By.xpath("//input[@name= 'Username']")).sendKeys("7897897897");
		driver.findElement(By.xpath("//input[@name= 'Password']")).sendKeys("123456");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Type the entered captcha to the text box
		driver.findElement(By.xpath("//input[@id= 'cpatchaTextBox']")).sendKeys(captchaVal);
		driver.findElement(By.xpath("//button[@class= 'btn btn-primary']")).click();
		Thread.sleep(3000);
		
  }

}
